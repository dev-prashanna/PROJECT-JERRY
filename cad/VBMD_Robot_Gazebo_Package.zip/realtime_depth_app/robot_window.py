"""Separate Qt live RGB/depth window for the robot integration."""
import os,time
from pathlib import Path
import numpy as np
import cv2
# OpenCV's bundled Qt plugins can conflict with PySide6; use PySide's plugin directory.
import PySide6
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH']=str(Path(PySide6.__file__).resolve().parent/'Qt/plugins')
from PySide6 import QtCore,QtGui,QtWidgets


def run_window(node,worker,args,save):
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    app.setApplicationName('VBMD Robot Vision')
    class Window(QtWidgets.QMainWindow):
        def __init__(self):
            super().__init__();self.setWindowTitle('VBMD • Live camera, depth and ultrasonic avoidance');self.resize(1320,810)
            root=QtWidgets.QWidget();self.setCentralWidget(root);layout=QtWidgets.QVBoxLayout(root);layout.setContentsMargins(20,14,20,16);layout.setSpacing(10)
            self.setStyleSheet('''QMainWindow,QWidget{background:#111b25;color:#e7edf4;font-family:Sans Serif;font-size:14px;} QLabel#title{font-size:24px;font-weight:700;} QLabel#subtitle{color:#a9bdce;} QLabel#card{background:#1a2a39;border-radius:9px;padding:10px;} QPushButton{background:#253d51;border:1px solid #3d5b72;border-radius:7px;padding:10px 16px;} QPushButton:hover{background:#355871;} QPushButton#start{background:#166e5b;} QPushButton#stop{background:#9c3543;}''')
            title=QtWidgets.QLabel('VBMD / ROBOT VISION');title.setObjectName('title');layout.addWidget(title)
            sub=QtWidgets.QLabel('Gazebo RGB → your Depth Anything V2 model   •   relative proximity + measured ultrasonic ranges');sub.setObjectName('subtitle');layout.addWidget(sub)
            panes=QtWidgets.QHBoxLayout();self.images=[]
            for title in ['CAMERA / DEPTH-ALIGNED FRAME','RELATIVE DEPTH / WARM = NEAR · COOL = FAR']:
                col=QtWidgets.QVBoxLayout();col.addWidget(QtWidgets.QLabel(title));label=QtWidgets.QLabel('Waiting for camera and depth model…');label.setMinimumSize(480,300);label.setAlignment(QtCore.Qt.AlignCenter);label.setStyleSheet('background:#080f16;border:1px solid #30465b;border-radius:8px;');col.addWidget(label,1);panes.addLayout(col,1);self.images.append(label)
            layout.addLayout(panes,1)
            row=QtWidgets.QHBoxLayout();self.cards={}
            for side in ['front','left','rear','right']:
                label=QtWidgets.QLabel(side.upper()+' ULTRASONIC\nWaiting for reading');label.setObjectName('card');label.setMinimumHeight(66);row.addWidget(label,1);self.cards[side]=label
            layout.addLayout(row)
            self.state=QtWidgets.QLabel('MONITOR • no motion commanded');self.state.setStyleSheet('font-size:19px;font-weight:600;padding:7px;background:#203449;border-radius:7px;');layout.addWidget(self.state)
            self.stats=QtWidgets.QLabel('Loading model…');self.stats.setObjectName('subtitle');layout.addWidget(self.stats)
            self.sectors=QtWidgets.QLabel('Left / center / right proximity: waiting');layout.addWidget(self.sectors)
            row=QtWidgets.QHBoxLayout();self.start=QtWidgets.QPushButton('Start avoidance');self.start.setObjectName('start');self.start.clicked.connect(lambda:node.arm(True));row.addWidget(self.start)
            stop=QtWidgets.QPushButton('STOP / monitor only');stop.setObjectName('stop');stop.clicked.connect(lambda:node.arm(False));row.addWidget(stop)
            capture=QtWidgets.QPushButton('Save current view');capture.clicked.connect(self.capture);row.addWidget(capture);row.addStretch();row.addWidget(QtWidgets.QLabel('Space: stop   •   A: arm   •   Esc: close'));layout.addLayout(row)
            self.shortcuts=[]
            for key,fn in [('Space',lambda:node.arm(False)),('A',lambda:node.arm(True)),('Esc',self.close)]:
                shortcut=QtGui.QShortcut(QtGui.QKeySequence(key),self);shortcut.activated.connect(fn);self.shortcuts.append(shortcut)
            self.timer=QtCore.QTimer(self);self.timer.timeout.connect(self.refresh);self.timer.start(50);self.opened=time.monotonic()
        def capture(self):
            save();args.output.mkdir(parents=True,exist_ok=True);self.grab().save(str(args.output/'dashboard.png'))
        def refresh(self):
            frame,p,rs,d,active=node.snapshot();now=time.monotonic()
            for side,label in self.cards.items():
                r=rs.get(side)
                if not r:txt='WAITING';color='#c48b37';age=''
                elif not r.usable():txt='STALE / INVALID';color='#ed6b6b';age=f'age {r.age_wall:.2f}s'
                else:
                    txt='NO ECHO · 4 m limit' if r.value==np.inf else ('TOO CLOSE' if r.value==-np.inf else f'{r.value:.3f} m')
                    color='#ed6b6b' if r.clearance()<.25 else '#72d2ad';age=f'age {r.age_wall:.2f}s'
                label.setText(f'<b>{side.upper()} ULTRASONIC</b><br><span style="color:{color};font-size:21px">{txt}</span> <span style="color:#9db1c3">{age}</span>')
            if p:
                bgr=p.packet.bgr.copy();heat=cv2.applyColorMap(np.uint8(np.clip(p.view.proximity,0,1)*255),cv2.COLORMAP_TURBO)
                h,w=bgr.shape[:2]
                for i,(a,b) in enumerate([(.06,.34),(.34,.66),(.66,.94)]):
                    color=(80,200,120) if p.view.fractions[i]<.22 else (70,100,245)
                    for img in [bgr,heat]:
                        cv2.rectangle(img,(int(a*w),int(.2*h)),(int(b*w),int(.7*h)),color,2)
                        cv2.putText(img,['LEFT','CENTER','RIGHT'][i],(int(a*w)+6,int(.2*h)+22),cv2.FONT_HERSHEY_SIMPLEX,.5,color,1,cv2.LINE_AA)
                for label,img in zip(self.images,[bgr,heat]):
                    rgb=np.ascontiguousarray(img[:,:,::-1]);q=QtGui.QImage(rgb.data,rgb.shape[1],rgb.shape[0],rgb.strides[0],QtGui.QImage.Format_RGB888).copy();label.setPixmap(QtGui.QPixmap.fromImage(q).scaled(label.size(),QtCore.Qt.KeepAspectRatio,QtCore.Qt.SmoothTransformation))
                age=now-p.packet.received
                self.stats.setText(f'{worker.status}  •  inference {p.inference_ms:.1f} ms  •  prediction age {age*1000:.0f} ms  •  input frame #{p.packet.id}  •  colour map: relative, not metres')
                self.sectors.setText('Relative proximity (0 farther → 1 nearer):  '+ '    '.join(f'{name} {score:.2f} / near pixels {frac:.0%}' for name,score,frac in zip(['LEFT','CENTER','RIGHT'],p.view.scores,p.view.fractions)))
            elif frame:
                rgb=np.ascontiguousarray(frame.bgr[:,:,::-1]);q=QtGui.QImage(rgb.data,rgb.shape[1],rgb.shape[0],rgb.strides[0],QtGui.QImage.Format_RGB888).copy();self.images[0].setPixmap(QtGui.QPixmap.fromImage(q).scaled(self.images[0].size(),QtCore.Qt.KeepAspectRatio,QtCore.Qt.SmoothTransformation));self.stats.setText(worker.status)
            else:self.stats.setText(worker.status+' • waiting for /camera/image_raw')
            self.state.setText(f'{d.state}  •  {d.reason}   |   v={d.linear:.2f} m/s   yaw={d.angular:.2f} rad/s')
            self.start.setText('Avoidance active' if active else 'Start avoidance')
            if worker.error:self.stats.setText(worker.status)
            if node.spin_error:self.stats.setText('ROS ERROR — control stopped; see terminal for details')
            if args.duration and now-self.opened>=args.duration:self.capture();self.close()
        def keyPressEvent(self,event):
            if event.key()==QtCore.Qt.Key_Space:node.arm(False)
            elif event.key()==QtCore.Qt.Key_A:node.arm(True)
            elif event.key()==QtCore.Qt.Key_Escape:self.close()
            else:super().keyPressEvent(event)
        def closeEvent(self,event):
            node.arm(False);self.timer.stop();save();event.accept()
    win=Window();win.show();app.exec()
