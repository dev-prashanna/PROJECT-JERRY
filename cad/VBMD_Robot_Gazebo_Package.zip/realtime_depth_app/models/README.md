# This folder intentionally contains no model weights.

The application loads Depth Anything V2 from the Hugging Face cache that already exists on
this machine:

    ~/.cache/huggingface/hub/models--depth-anything--Depth-Anything-V2-Small-hf

and does so offline (`model.local_files_only: true` in `config.yaml`), so nothing is
downloaded at runtime.

To use a different checkpoint, either:

1. point `model.repo_id` at another cached repo (e.g. `LiheYoung/depth-anything-small-hf`,
   also already cached), or
2. set `model.local_dir: /path/to/local/checkpoint` to a directory containing
   `config.json` + `model.safetensors`.

If a checkpoint is ever added to this folder, document here: source URL, SHA-256 of
`model.safetensors`, license (Depth Anything V2 weights are CC-BY-NC-SA 4.0 - **commercial use
is not permitted**), and the date retrieved.
