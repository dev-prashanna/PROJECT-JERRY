#!/usr/bin/env python3
"""Live Gazebo RGB/depth dashboard and conservative local avoidance using the existing DepthEngine."""
from __future__ import annotations
import argparse,os,time,threading,json,sys,importlib,types
from pathlib import Path
from dataclasses import dataclass
from collections import deque
import numpy as np
# Isolate the existing depth app's relative imports from the repository's unrelated src package.
backend=types.ModuleType('vbmd_depth_backend');backend.__path__=[str(Path(__file__).resolve().parent/'src')];sys.modules['vbmd_depth_backend']=backend
from vbmd_depth_backend.config import load_config,validate_config
from vbmd_depth_backend.camera import LatestSlot
from vbmd_depth_backend.robot_avoidance import RangeReading,analyze_depth,AvoidancePolicy,Decision,SIDES
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from rclpy.clock import Clock as RosClock
from rclpy.clock import ClockType
from rclpy.parameter_client import AsyncParameterClient
from rclpy.parameter import Parameter
from sensor_msgs.msg import Image,Range
from geometry_msgs.msg import Twist
from rosgraph_msgs.msg import Clock
from std_msgs.msg import String,Int32
from std_srvs.srv import SetBool

@dataclass
class Packet:
    id:int
    bgr:np.ndarray
    received:float
    stamp:object
    frame_id:str
@dataclass
class Prediction:
    packet:Packet
    depth:np.ndarray
    view:object
    inference_ms:float
    device:str
    finished:float

class DepthWorker(threading.Thread):
    def __init__(self,frames,results,cfg):
        super().__init__(daemon=True,name='robot-depth');self.frames=frames;self.results=results;self.cfg=cfg;self.stop_event=threading.Event();self.status='Loading existing depth model';self.error=None;self.processed=0
    def run(self):
        try:
            from vbmd_depth_backend.depth_engine import DepthEngine
            engine=DepthEngine(self.cfg);self.status='Model ready on '+str(engine.device);seq=0
            while not self.stop_event.is_set():
                seq,packet=self.frames.wait_new(seq,.2)
                if packet is None:continue
                out=engine.infer(packet.bgr,frame_id=packet.id)
                view=analyze_depth(out.depth,out.meta.convention)
                self.results.put(Prediction(packet,out.depth,view,out.inference_ms,str(engine.device),time.monotonic()));self.processed+=1
        except Exception as exc:
            import traceback
            self.error=traceback.format_exc();self.status='Depth error: '+str(exc);print(self.error,file=sys.stderr,flush=True)
    def stop(self):self.stop_event.set();self.frames.close()

class RobotNode(Node):
    def __init__(self,frames,results,worker,auto=False):
        super().__init__('vbmd_depth_avoidance');self.frames=frames;self.results=results;self.worker=worker
        self.lock=threading.RLock();self.sonars={};self.frame=None;self.frame_count=0;self.sim_time=None;self.clock_received=-1e9
        self.active=False;self.arming=False;self.auto_pending=auto;self.spin_error=None;self.arm_generation=0;self.parameter_client=AsyncParameterClient(self,'/vbmd_gazebo_adapter');self.prediction=None;self.policy=AvoidancePolicy();self.decision=Decision(0.,0.,'MONITOR','Avoidance not armed')
        self.history=deque(maxlen=1000);self.last_depth_id=-1;self.started=time.monotonic();self.enabled_commands=0
        self.command_pub=self.create_publisher(Twist,'/cmd_vel',10)
        self.depth_pub=self.create_publisher(Image,'/perception/depth_relative',qos_profile_sensor_data)
        self.status_pub=self.create_publisher(String,'/perception/avoidance_status',10)
        self.create_subscription(Image,'/camera/image_raw',self.image,qos_profile_sensor_data)
        self.create_subscription(Clock,'/clock',self.clock,10)
        for side in SIDES:self.create_subscription(Range,'/ultrasonic/'+side,lambda m,s=side:self.range(s,m),qos_profile_sensor_data)
        self.create_subscription(Int32,'/sim/keyboard',self.keyboard,10)
        self.create_service(SetBool,'/perception/set_avoidance',self.set_avoidance)
        self.create_timer(.05,self.control,clock=RosClock(clock_type=ClockType.STEADY_TIME))
    def clock(self,m):
        with self.lock:self.sim_time=m.clock.sec+m.clock.nanosec*1e-9;self.clock_received=time.monotonic()
    def image(self,m):
        if m.encoding not in ('rgb8','bgr8','rgba8','bgra8'):return
        channels=4 if 'a' in m.encoding else 3
        arr=np.frombuffer(m.data,np.uint8).reshape(m.height,m.step)[:,:m.width*channels].reshape(m.height,m.width,channels)[:,:,:3]
        if m.encoding.startswith('rgb'):arr=arr[:,:,::-1]
        with self.lock:
            self.frame_count+=1;self.frame=Packet(self.frame_count,arr.copy(),time.monotonic(),m.header.stamp,m.header.frame_id);self.frames.put(self.frame)
    def range(self,side,m):
        with self.lock:self.sonars[side]=(float(m.range),time.monotonic(),m.header.stamp.sec+m.header.stamp.nanosec*1e-9,float(m.min_range),float(m.max_range))
    def keyboard(self,m):
        if m.data in [87,83,65,68,88,32,16777235,16777237,16777234,16777236]:self.arm(False,'Gazebo keyboard took manual control')
    def arm(self,enabled,why='Avoidance not armed'):
        with self.lock:
            self.auto_pending=False;self.arm_generation+=1;generation=self.arm_generation;was=self.active;self.active=False;self.arming=False;self.policy.reset()
            if was:self.command_pub.publish(Twist())
            if not enabled:
                self.decision=Decision(0.,0.,'MONITOR',why);return
            if self.spin_error:
                self.decision=Decision(0.,0.,'STOP','ROS connection failed');return
            if not self.parameter_client.services_are_ready():
                self.decision=Decision(0.,0.,'STOP','Gazebo command adapter unavailable');return
            self.arming=True;self.decision=Decision(0.,0.,'ARMING','Disabling the adapter’s sonar-only autonomy')
            future=self.parameter_client.set_parameters([Parameter('autonomy',value=False)])
            def done(result):
                with self.lock:
                    if generation!=self.arm_generation:return
                    self.arming=False
                    try:
                        response=result.result()
                        if not all(r.successful for r in response.results):raise RuntimeError('Adapter rejected mode change')
                        self.active=True
                    except Exception as exc:self.decision=Decision(0.,0.,'STOP','Could not acquire command control: '+str(exc))
            future.add_done_callback(done)
    def set_avoidance(self,request,response):
        self.arm(request.data)
        response.success=(not request.data) or self.active or self.arming
        response.message='Arming requested; check avoidance_status' if request.data and response.success else self.decision.reason
        return response
    def readings(self,now):
        return {s:RangeReading(v,now-recv,(self.sim_time-ts) if self.sim_time is not None else 1e9,minimum,maximum) for s,(v,recv,ts,minimum,maximum) in self.sonars.items()}
    def control(self):
        with self.lock:
            if self.auto_pending and self.parameter_client.services_are_ready():self.arm(True)
            now=time.monotonic();new=self.results.get()
            if new:self.prediction=new
            p=self.prediction;rs=self.readings(now)
            camera_age=now-self.frame.received if self.frame else 1e9
            depth_age=now-p.packet.received if p else 1e9
            ros_depth_age=(self.sim_time-p.packet.stamp.sec-p.packet.stamp.nanosec*1e-9) if p and self.sim_time is not None else 1e9
            d=self.policy.decide(p.view if p else None,rs,now,max(depth_age,max(0.,ros_depth_age)),camera_age,now-self.clock_received)
            if self.worker.error:d=Decision(0.,0.,'STOP','Depth inference failed')
            if self.active:
                self.decision=d;m=Twist();m.linear.x=d.linear;m.angular.z=d.angular;self.command_pub.publish(m);self.enabled_commands+=1
            elif not self.arming:self.decision=Decision(0.,0.,'MONITOR','Preview only - press Start avoidance')
            if p and p.packet.id!=self.last_depth_id:
                self.last_depth_id=p.packet.id
                out=Image();out.header.stamp=p.packet.stamp;out.header.frame_id=p.packet.frame_id;out.width=p.depth.shape[1];out.height=p.depth.shape[0];out.encoding='32FC1';out.step=out.width*4;out.is_bigendian=0;out.data=np.asarray(p.depth,dtype='<f4').tobytes();self.depth_pub.publish(out)
            status={'active':self.active,'state':self.decision.state,'reason':self.decision.reason,'linear_m_s':self.decision.linear,'yaw_rad_s':self.decision.angular,'depth_unit':'relative inverse depth, not metres','depth_age_wall_s':depth_age if p else None,'depth_age_sensor_s':ros_depth_age if p else None,'inference_ms':p.inference_ms if p else None,'scores':list(p.view.scores) if p else None,'near_coverage':list(p.view.fractions) if p else None,'ultrasound_m':{s:(r.value if np.isfinite(r.value) else ('NO_ECHO' if r.value==np.inf else 'TOO_CLOSE')) for s,r in rs.items()},'ultrasound_age_s':{s:r.age_wall for s,r in rs.items()},'frame_id':p.packet.id if p else None,'suggested_state':d.state,'suggested_reason':d.reason,'suggested_linear_m_s':d.linear,'suggested_yaw_rad_s':d.angular}
            msg=String();msg.data=json.dumps(status);self.status_pub.publish(msg);self.history.append(status)
    def snapshot(self):
        with self.lock:return self.frame,self.prediction,self.readings(time.monotonic()),self.decision,self.active


def spin_node(node):
    from rclpy.executors import ExternalShutdownException
    try:rclpy.spin(node)
    except ExternalShutdownException:pass
    except Exception:
        import traceback
        node.spin_error=traceback.format_exc();node.arm(False);print(node.spin_error,file=sys.stderr,flush=True)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--auto',action='store_true');ap.add_argument('--headless',action='store_true');ap.add_argument('--duration',type=float,default=0);ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'robot_outputs');ap.add_argument('--input-size',type=int,default=392);ap.add_argument('--device',default='auto');args=ap.parse_args()
    cfg=load_config();cfg.model.input_size=args.input_size;cfg.model.device=args.device;cfg.model.warmup_iters=1;cfg.model.precision='autocast_fp16' if args.device!='cpu' else 'fp32'
    # CUDA mode is selected only if available; leave CPU fallback in supported precision.
    import torch
    torch.set_num_threads(4)
    if not torch.cuda.is_available():cfg.model.precision='fp32'
    cfg.depth.smoothing.enabled=False
    validate_config(cfg)
    frames=LatestSlot();results=LatestSlot();worker=DepthWorker(frames,results,cfg)
    rclpy.init();node=RobotNode(frames,results,worker,args.auto);spin=threading.Thread(target=lambda:spin_node(node),daemon=True);spin.start();worker.start()
    def save():
        args.output.mkdir(parents=True,exist_ok=True);frame,p,rs,d,active=node.snapshot()
        report={'checkpoint':cfg.model.repo_id,'device':p.device if p else None,'depth_predictions':worker.processed,'last_processed_frame_id':node.last_depth_id,'received_frames':node.frame_count,'worker_status':worker.status,'worker_error':worker.error,'ros_error':node.spin_error,'commands_published':node.enabled_commands,'history':list(node.history)}
        (args.output/'live_report.json').write_text(json.dumps(report,indent=2))
        if p:
            import cv2
            cv2.imwrite(str(args.output/'rgb.png'),p.packet.bgr);cv2.imwrite(str(args.output/'relative_depth.png'),cv2.applyColorMap(np.uint8(np.clip(p.view.proximity,0,1)*255),cv2.COLORMAP_TURBO))
    try:
        if args.headless:
            until=time.monotonic()+(args.duration or 15)
            while time.monotonic()<until and not worker.error and not node.spin_error:time.sleep(.1)
            save()
            if worker.error or node.spin_error or node.prediction is None:raise RuntimeError(node.spin_error or worker.status)
        else:
            from robot_window import run_window
            run_window(node,worker,args,save)
    finally:
        node.arm(False);worker.stop();rclpy.shutdown();spin.join(timeout=2);worker.join(timeout=3);node.destroy_node()
if __name__=='__main__':main()
