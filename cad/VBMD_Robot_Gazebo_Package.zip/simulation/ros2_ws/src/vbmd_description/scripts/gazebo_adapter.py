#!/usr/bin/env python3
"""Four narrow beam proxies -> ultrasound Range; command watchdog; optional reactive avoidance."""
import math
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan,Range
from geometry_msgs.msg import Twist
from std_msgs.msg import Int32
from rclpy.parameter import Parameter
SIDES=('front','left','rear','right')
class GazeboAdapter(Node):
 def __init__(self):
  super().__init__('vbmd_gazebo_adapter')
  self.declare_parameter('autonomy',False);self.cache={};self.ranges={s:math.inf for s in SIDES};self.index=0
  self.command=Twist();self.last_command=-1e9;self.avoid_direction=0.;self.avoid_start=0.
  self.output=self.create_publisher(Twist,'/sim/cmd_vel_safe',10)
  self.pubs={s:self.create_publisher(Range,'/ultrasonic/'+s,10) for s in SIDES}
  self.subs=[self.create_subscription(LaserScan,'/sim/sonar_rays/'+s,lambda m,side=s:self.cache.__setitem__(side,m),qos_profile_sensor_data) for s in SIDES]
  self.create_subscription(Twist,'/cmd_vel',self.receive,10)
  self.create_subscription(Int32,'/sim/keyboard',self.keyboard,10)
  self.create_timer(.06,self.publish_range);self.create_timer(.02,self.drive)
  self.get_logger().info('Gazebo adapter ready: one RGB camera + four ultrasound Range topics; no odometry or lidar scan exposed to navigation.')
 def seconds(self):return self.get_clock().now().nanoseconds*1e-9
 def receive(self,msg):
  if not all(math.isfinite(v) for v in [msg.linear.x,msg.angular.z]):msg=Twist()
  msg.linear.x=max(-.22,min(.22,msg.linear.x));msg.angular.z=max(-2.,min(2.,msg.angular.z))
  self.command=msg;self.last_command=self.seconds()
 def keyboard(self,msg):
  keys={87:(.10,0.),83:(-.08,0.),65:(0.,.8),68:(0.,-.8),88:(0.,0.),32:(0.,0.),16777235:(.10,0.),16777237:(-.08,0.),16777234:(0.,.8),16777236:(0.,-.8)}
  if msg.data not in keys:return
  self.set_parameters([Parameter('autonomy',value=False)])
  v,w=keys[msg.data];m=Twist();m.linear.x=v;m.angular.z=w;self.receive(m)
 def publish_range(self):
  side=SIDES[self.index%4];self.index+=1
  if side not in self.cache:return
  scan=self.cache[side]
  age=self.seconds()-(scan.header.stamp.sec+scan.header.stamp.nanosec*1e-9)
  if age>.30 or age<-.1:return
  # Keep the source measurement timestamp; never relabel stale data as newly acquired.
  hits=[r for r in scan.ranges if math.isfinite(r) and scan.range_min<=r<=scan.range_max]
  val=min(hits,default=math.inf);self.ranges[side]=val
  out=Range();out.header=scan.header;out.header.frame_id=side+'_ultrasonic_frame';out.radiation_type=Range.ULTRASOUND
  out.field_of_view=float(scan.angle_max-scan.angle_min);out.min_range=scan.range_min;out.max_range=scan.range_max;out.range=val
  self.pubs[side].publish(out)
 def reactive(self):
  if not all(s in self.cache for s in SIDES):return 0.,0.
  # Stop if camera/range simulation stalls or the current data becomes stale.
  now=self.seconds()
  if any(now-(m.header.stamp.sec+m.header.stamp.nanosec*1e-9)>.30 for m in self.cache.values()):return 0.,0.
  f=self.ranges['front'];l=self.ranges['left'];r=self.ranges['right']
  if self.avoid_direction:
   if f>.40 and now-self.avoid_start>1.:self.avoid_direction=0.
   else:return 0.,self.avoid_direction
  if f<.30:
   self.avoid_direction=-.9 if r>l else .9;self.avoid_start=now;return 0.,self.avoid_direction
  if l<.13:return .035,-.6
  if r<.13:return .035,.6
  return .08,0.
 def drive(self):
  if self.get_parameter('autonomy').value:
   v,w=self.reactive();m=Twist();m.linear.x=v;m.angular.z=w
  else:m=self.command if self.seconds()-self.last_command<.5 else Twist()
  self.output.publish(m)
def main():
 rclpy.init();node=GazeboAdapter()
 try:rclpy.spin(node)
 except KeyboardInterrupt:pass
 finally:node.output.publish(Twist());node.destroy_node();rclpy.shutdown()
if __name__=='__main__':main()
