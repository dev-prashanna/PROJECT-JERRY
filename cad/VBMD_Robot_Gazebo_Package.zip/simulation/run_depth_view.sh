#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")/.."
source /opt/ros/jazzy/setup.bash
export ROS_DOMAIN_ID="${ROS_DOMAIN_ID:-86}"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
unset QT_PLUGIN_PATH QT_QPA_PLATFORM_PLUGIN_PATH
exec python3 realtime_depth_app/robot_live.py "$@"
